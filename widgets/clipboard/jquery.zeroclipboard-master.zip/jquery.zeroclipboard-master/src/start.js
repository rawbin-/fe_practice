(function($, window, undefined) {
  "use strict";

  var require, module, exports;  //jshint ignore:line

  var zcExistsAlready = !!window.ZeroClipboard;
