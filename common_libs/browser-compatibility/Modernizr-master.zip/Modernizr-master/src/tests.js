define(function() {
  var tests = [];
  return tests;
});
